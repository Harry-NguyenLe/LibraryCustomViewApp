package vn.edu.csc.librarycustomviewapp.CustomRatingBar;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import vn.edu.csc.librarycustomviewapp.R;

public class CustomRatingBar extends LinearLayout {
    //TODO: làm chưa xong phần này
    Context mContext;
    ImageView iv_rating1, iv_rating2, iv_rating3, iv_rating4, iv_rating5;
    ArrayList<ImageView> mListRating;


    public CustomRatingBar(Context context) {
        super(context);
    }

    public CustomRatingBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        addControls(attrs);
    }

    public CustomRatingBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        addControls(attrs);
    }

    private void addControls(AttributeSet attrs) {
        iv_rating1 = findViewById(R.id.iv_rating1);
        iv_rating2 = findViewById(R.id.iv_rating2);
        iv_rating3 = findViewById(R.id.iv_rating3);
        iv_rating4 = findViewById(R.id.iv_rating4);
        iv_rating5 = findViewById(R.id.iv_rating5);

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        CustomRatingBar customRatingBar = (CustomRatingBar) layoutInflater.inflate(R.layout.rating_bar_layout, this);

        mListRating.addAll(Arrays.asList(iv_rating1, iv_rating2, iv_rating3, iv_rating4, iv_rating5));


    }
}
