package vn.edu.csc.librarycustomviewapp.Activity2.View;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import java.util.List;

import vn.edu.csc.librarycustomviewapp.Activity2.Model.Note;
import vn.edu.csc.librarycustomviewapp.Activity2.ViewModel.NoteViewModel;
import vn.edu.csc.librarycustomviewapp.R;

public class ActivitySecond extends AppCompatActivity {
    private NoteViewModel noteViewModel;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);
        noteViewModel.getAllNotes()
                    .observe(this, v -> {
                        //update recyclerview
                        Toast.makeText(this, "onChanged", Toast.LENGTH_SHORT).show();
                    });
    }


}
