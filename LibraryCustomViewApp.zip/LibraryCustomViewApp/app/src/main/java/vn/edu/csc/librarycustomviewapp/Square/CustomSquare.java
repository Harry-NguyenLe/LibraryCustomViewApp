package vn.edu.csc.librarycustomviewapp.Square;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class CustomSquare extends View {
    private final static int SQUARE_SIZE = 100;
    private Paint mPaint;
    private RectF mRectf;
    private static final float left = 100;
    private static final float top = 100;
    private static final float right = left + 100;
    private static final float bottom = top + 100;


    public CustomSquare(Context context) {
        super(context);
    }

    public CustomSquare(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomSquare(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void init(){
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mRectf = new RectF();
        mRectf.set(left, top, right, bottom);
        mPaint.setColor(Color.DKGRAY);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //to draw a shape on a canvas we should use Rectf object, remember not to call object when in UI creating process, it may crash the app
        init();
        canvas.drawRect(mRectf, mPaint);
        super.onDraw(canvas);
    }
}
